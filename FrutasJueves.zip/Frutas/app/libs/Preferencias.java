package com.example.preferencias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SeekBar skb_Bar;
    EditText edt_Text;
    Button btn_save;

    SharedPreferences preferencias;
    String prefNombre;
    int progreso;
    static final String FONT_SIZE_KEY = "tamaño_fuente";
    static final String TEXT_VALUE_KEY = "valor_texto";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        skb_Bar = (SeekBar) findViewById(R.id.skb_barra);
        edt_Text = (EditText) findViewById(R.id.txt_texto);
        btn_save = (Button) findViewById(R.id.btn_guardar);

        preferencias = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor=preferencias.edit();

        float fontSize= preferencias.getFloat(FONT_SIZE_KEY, 25);
        skb_Bar.setProgress((int) fontSize-25);


        String texto = preferencias.getString(TEXT_VALUE_KEY, "");
        edt_Text.setText(texto);
        edt_Text.setTextSize(fontSize);



        skb_Bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                progreso=progress + 20;
                edt_Text.setTextSize(progreso);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor.putFloat(FONT_SIZE_KEY, (float) progreso);
                editor.putString(TEXT_VALUE_KEY, edt_Text.getText().toString());
                editor.commit();
                Toast.makeText(getApplicationContext(), "Los datos se han guardado",
                        Toast.LENGTH_LONG).show();
            }
        });



    }
}











/*
DeviceSharePreferece en View   (captura de pantalla)


*/