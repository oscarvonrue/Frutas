package com.example.cuadrodialogo1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_dialog_1, btn_dialog_2, btn_dialog_3;
    CharSequence[] items = {"Opción 1", "Opción 2", "Opción 3", "Opción 4"};
    boolean[] itemsChecked = new boolean[items.length];


    private static final int CUADRO_DIALOGO_ERROR_CRITICO = 1;
    private static final int CUADRO_DIALOGO_OPCIONES = 2;
    private static final int CUADRO_LOGIN = 3;
    private static final int CUADRO_ADVERTENCIA = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_dialog_1 = (Button) findViewById(R.id.btn_dialogo_1);
        btn_dialog_2 = (Button) findViewById(R.id.btn_dialogo_2);
        btn_dialog_3 = (Button) findViewById(R.id.btn_dialogo_3);


        btn_dialog_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDialog(CUADRO_DIALOGO_ERROR_CRITICO);
            }
        });

        btn_dialog_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDialog(CUADRO_DIALOGO_OPCIONES);
            }
        });

        btn_dialog_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(CUADRO_LOGIN);
            }
        });


    }

    @Override
    protected Dialog onCreateDialog(int id) {

        Dialog dialogo = null;
        switch(id){
            case CUADRO_DIALOGO_ERROR_CRITICO:
                dialogo = crearDialogoErrorCritico();
                break;
            case CUADRO_DIALOGO_OPCIONES:
                dialogo = crearDialogoOpciones();
                break;
            case CUADRO_LOGIN:
                dialogo = crearDialogoLogin();
                break;
            case CUADRO_ADVERTENCIA:
                dialogo = crearDialogoAdvertencia();
                break;
            default:
                dialogo = null;
        }
        return dialogo;
    }

    private Dialog crearDialogoAdvertencia() {
        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Advertencia")
                .setView(R.layout.dialog_warning)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .create();

    }

    private Dialog crearDialogoLogin() {
        //Recoger el layout inflater
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_login, null);
        //Declarar objetos y referenciar con controles
        EditText edt_user, edt_password;
        edt_user = (EditText) dialogView.findViewById(R.id.edt_usuario);
        edt_password = (EditText) dialogView.findViewById(R.id.edt_contrasena);

        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Login")
                .setView(dialogView)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "El usuario es "
                                        + edt_user.getText().toString()
                                        + " y su contraseña es "
                                        + edt_password.getText().toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(CUADRO_ADVERTENCIA);
                    }
                })
                .create();
    }

    private Dialog crearDialogoOpciones() {
        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Cuadro diálogo opciones")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(CUADRO_ADVERTENCIA);
                    }
                })
                .setMultiChoiceItems(items,
                        itemsChecked,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface,
                                                int which,
                                                boolean isChecked) {
                                Toast.makeText(getApplicationContext(),
                                        "Has hecho clic en " + items[which]
                                                + " y lo has " + (isChecked?" marcado": " desmarcado"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        })
                .create();

    }

    private Dialog crearDialogoErrorCritico() {

        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Error crítico")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(CUADRO_ADVERTENCIA);
                    }
                })
                .setMessage("¿Desea borrar todos los datos?")
                .create();
    }


}