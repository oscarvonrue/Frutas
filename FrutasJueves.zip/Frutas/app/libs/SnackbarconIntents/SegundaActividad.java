package com.example.ejemplootrotipolisteners;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SegundaActividad extends AppCompatActivity {

    TextView txt_output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);

        txt_output = (TextView) findViewById(R.id.txt_resultado);

        Bundle bundle = getIntent().getExtras();
        String texto = bundle.getString("texto").toString();
        int repeticiones = bundle.getInt("repeticiones");

        String mensaje = "";

        for (int i=1; i<=repeticiones; i++) {
            mensaje+=texto + " ";
        }

        txt_output.setText(mensaje);





    }
}