package com.example.ejemplootrotipolisteners;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    EditText edt_text, edt_times;
    Button btn_go;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_text = (EditText) findViewById(R.id.edt_texto);
        edt_times = (EditText) findViewById(R.id.edt_repeticiones);
        btn_go = (Button) findViewById(R.id.btn_ir);

        //Otra manera de implementar el listener del botón
        //recordatorio: en el layout hay que editar el atributo onClick


        //Manera ya conocida de implementar el listener del botón
        /*btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //comprobamos que los datos son válidos
                if (edt_text.getText().toString().equals("") ||
                edt_times.getText().toString().equals("")) {
                    //mostrar aviso al usuario
                    //edt_text.setError("No puedes dejar este campo en blanco");

                    //otra posibilidad es mostrar un mensaje emergente o Toast
                    *//*Toast.makeText(getApplicationContext(),
                            "No se pueden dejar campos en blanco",
                            Toast.LENGTH_LONG).show();*//*

                    //otra posibilidad es mostrar un mensaje emergente Snackbar
                    Snackbar.make(findViewById(R.id.mi_layout),
                                    R.string.txt_campos_blanco,
                                    Snackbar.LENGTH_LONG)
                            .show();
                } else {
                    int num_repeticiones=0;
                    num_repeticiones = Integer.parseInt(edt_times.getText().toString());

                    Intent intent = new Intent(MainActivity.this,
                            SegundaActividad.class);

                    Bundle bundle = new Bundle();
                    bundle.putString("texto", edt_text.getText().toString());
                    bundle.putInt("repeticiones", num_repeticiones);

                    intent.putExtras(bundle);
                    startActivity(intent);


                }
            }
        });*/
    }

    public void llamada_intent(View view) {

        //comprobamos que los datos son válidos
        if (edt_text.getText().toString().equals("") ||
                edt_times.getText().toString().equals("")) {
            //mostrar aviso al usuario
            //edt_text.setError("No puedes dejar este campo en blanco");

            //otra posibilidad es mostrar un mensaje emergente o Toast
                    /*Toast.makeText(getApplicationContext(),
            "No se pueden dejar campos en blanco",
                    Toast.LENGTH_LONG).show();*/

            //otra posibilidad es mostrar un mensaje emergente Snackbar
            Snackbar.make(findViewById(R.id.mi_layout),
                            R.string.txt_campos_blanco,
                            Snackbar.LENGTH_LONG)
                    .show();
        } else {
            int num_repeticiones = 0;
            num_repeticiones = Integer.parseInt(edt_times.getText().toString());

            Intent intent = new Intent(MainActivity.this,
                    SegundaActividad.class);

            Bundle bundle = new Bundle();
            bundle.putString("texto", edt_text.getText().toString());
            bundle.putInt("repeticiones", num_repeticiones);

            intent.putExtras(bundle);
            startActivity(intent);
        }
    }
}