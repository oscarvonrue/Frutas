package com.example.ejemplofragmentos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction =fragmentManager.beginTransaction();

        Fragment fragment = new fragment_rojo();
        transaction.add(R.id.contenedor_fragments, fragment);
        Fragment fragmentVerde = new fragment_verde();
        transaction.add(R.id.contenedor_fragments_2, fragmentVerde);
        Fragment fragmentAzul = new fragment_azul();
        transaction.add(R.id.contenedor_fragments_3, fragmentAzul);
        transaction.commit();

        //TextView txt_view = (TextView) fragmentVerde.getView().findViewById(R.id.txt_verde);



    }

    public void clickEnBoton (View view) {
        Fragment fragment = null;
        

        switch (view.getId()) {
            case R.id.btn_rojo:
                fragment = new fragment_rojo();
                break;
            case R.id.btn_azul:
                fragment = new fragment_azul();
                break;
            case R.id.btn_verde:
                fragment = new fragment_verde();
                
                break;

        }
        
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contenedor_fragments, fragment).commit();
    }

}