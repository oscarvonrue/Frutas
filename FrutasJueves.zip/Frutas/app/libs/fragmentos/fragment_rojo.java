package com.example.ejemplofragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class fragment_rojo extends Fragment {
    TextView txt_rojo;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View inf =inflater.inflate(R.layout.fragment_rojo,
                 container, false);
        txt_rojo = (TextView) inf.findViewById(R.id.txt_rojo);
        txt_rojo.setText("He cambiado el texto");

        return inf;
    }
}