package com.example.actividadrepaso1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rdg_opciones;
    EditText edt_entrada_salida;

    int base_num_actual = 10;

    private static final int CUADRO_DIALOGO_FUERA_RANGO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdg_opciones = (RadioGroup) findViewById(R.id.rdg_opciones);
        edt_entrada_salida = (EditText) findViewById(R.id.edt_entrada_salida);

        rdg_opciones.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rdb_binario:
                        cambiar_a_base(2);
                        break;
                    case R.id.rdb_octal:
                        cambiar_a_base(8);
                        break;
                    case R.id.rdb_decimal:
                        cambiar_a_base(10);
                        break;
                    case R.id.rdb_hexadecimal:
                        cambiar_a_base(16);
                        break;
                    default:
                        break;
                }
            }
        });



    }

    private void cambiar_a_base(int base_num_destino) {
        //Si el campo está en blanco, no se realiza ninguna conversión
        if (edt_entrada_salida.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(),"Campo en blanco", Toast.LENGTH_LONG).show();
        } else {
            String numero = edt_entrada_salida.getText().toString();
            //Comprobamos si tiene prefijo y lo quitamos
            if (numero.startsWith("0b")) {
                base_num_actual = 2;
                numero = numero.substring(2,numero.length());
            } else if (numero.startsWith("0o")) {
                base_num_actual = 8;
                numero = numero.substring(2,numero.length());
            } else if (numero.startsWith("0d")) {
                base_num_actual = 10;
                numero = numero.substring(2,numero.length());
            } else if (numero.startsWith("0x")) {
                base_num_actual = 16;
                numero = numero.substring(2,numero.length());
            }

            //Inicializo variables locales
            int decimal=0;
            String salida="";
            try {
                //Paso 1: convierto a entero decimal como paso intermedio
                decimal = Integer.parseInt(numero, base_num_actual);

                //Compruebo si el número está dentro del rango permitido
                //en caso contrario, mostramos cuadro de diálogo
                if (decimal < 0  || decimal > 255) {
                    showDialog(CUADRO_DIALOGO_FUERA_RANGO);
                } else {
                    //Paso 2: convierto a base de destino desde base actual
                    switch (base_num_destino) {
                        case 2:
                            salida = "0b" + Integer.toBinaryString(decimal);
                            break;
                        case 8:
                            salida = "0o" + Integer.toOctalString(decimal);
                            break;
                        case 10:
                            salida = "0d" + Integer.toString(decimal);
                            break;
                        case 16:
                            salida = "0x" + Integer.toHexString(decimal);
                            break;
                    }
                }
            } catch (NumberFormatException e) {
                Toast.makeText(getApplicationContext(),"El número " + numero + " no está en base " + base_num_actual, Toast.LENGTH_LONG).show();
            }

            //Mostramos el resultado
            edt_entrada_salida.setText(salida);
        }
        //Actualizamos el estado
        base_num_actual = base_num_destino;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialogo = null;
        switch (id) {
            case CUADRO_DIALOGO_FUERA_RANGO:
                dialogo = crear_dialogo_fuera_rango();
                break;
            default:
                break;
        }

        return dialogo;

    }

    private Dialog crear_dialogo_fuera_rango() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Aviso")
                .setMessage("El dato debe ser un número entero entre 0 y 255 (decimal)")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Se cierra el cuadro de diálogo
                        dialog.cancel();
                    }
                });
        return builder.create();

    }
}