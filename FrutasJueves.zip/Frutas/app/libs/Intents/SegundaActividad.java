package com.example.ejemplointent1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class SegundaActividad extends AppCompatActivity {
    EditText edt_output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);

        edt_output = (EditText) findViewById(R.id.edt_resultado);

        //Recogemos los datos del bundle
        Bundle bundle2 = getIntent().getExtras();

        edt_output.setText("Hola, " + bundle2.getString("texto_entrada"));
    }
}