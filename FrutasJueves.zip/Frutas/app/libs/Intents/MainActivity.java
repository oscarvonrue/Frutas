package com.example.ejemplointent1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt_input;
    Button btn_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_input = (EditText) findViewById(R.id.edt_entrada);
        btn_send = (Button) findViewById(R.id.btn_enviar);

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Crea un objeto Intent para poder llamarlo
                Intent intent = new Intent(MainActivity.this,
                        SegundaActividad.class);
                //Creamos un objeto Bundle para poder enviar datos
                //entre las actividades
                Bundle bundle = new Bundle();
                bundle.putString("texto_entrada", edt_input.getText().toString());

                intent.putExtras(bundle);

                startActivity(intent);
            }
        });
    }
}