package com.example.ejemplointent1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TerceraActividad extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tercera_actividad);
    }
}