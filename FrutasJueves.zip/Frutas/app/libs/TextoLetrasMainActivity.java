package com.example.ejemplobotonesopcion1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    EditText edt_text;
    CheckBox chk_large;
    RadioGroup rdg_colors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_text = (EditText) findViewById(R.id.edt_texto);
        chk_large = (CheckBox) findViewById(R.id.chk_grande);
        rdg_colors = (RadioGroup) findViewById(R.id.rdg_colores);

        chk_large.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton,
                                         boolean isChecked) {
                if(isChecked) {
                    edt_text.setTextSize(40);
                } else {
                    edt_text.setTextSize(16);
                }
            }
        });

        rdg_colors.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup,
                                         int checkedId) {
                RadioButton rdb = (RadioButton) findViewById(checkedId);
                poner_color (rdb.getText().toString());

            }
        });
    }

    private void poner_color(String color) {
        switch (color) {
            case "Rojo":
                edt_text.setBackgroundColor(Color.RED);
                break;
            case "Verde":
                edt_text.setBackgroundColor(Color.GREEN);
                break;
            case "Azul":
                edt_text.setBackgroundColor(Color.BLUE);
                break;
            default:
                break;
        }

    }


}