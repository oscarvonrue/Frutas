package com.example.ejemplootrotipolisteners2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private static final int PEDIR_PERMISO_LLAMADA = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void llamada_intent (View view) {

        Intent intent = new Intent();
        switch (view.getId()) {


            case R.id.btn_navegador:
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://iescomercio.com/"));
                break;

            case R.id.btn_contactos:
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("content://contacts/people/"));
                break;

            case R.id.btn_mapas:
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("geo:42.469,-2.429?z=19"));
                break;

            case R.id.btn_telefono:
                if(Build.VERSION.SDK_INT >= 23) {
                    //si la versión de Android es igual o superior a 6.0
                    int tiene_permisos =
                            checkSelfPermission(Manifest.permission.CALL_PHONE);
                    if (tiene_permisos != PackageManager.PERMISSION_GRANTED) {
                        //no tiene permisos ---> hay que pedirlos
                        requestPermissions(new String[]{
                            Manifest.permission.CALL_PHONE},
                            PEDIR_PERMISO_LLAMADA);
                        return;
                        } else {
                        //tiene permisos
                        intent = new Intent(Intent.ACTION_CALL,
                                Uri.parse("tel:(+34)666777999"));
                    }
                } else {
                    //la versión de Android es inferior a 6.0
                    intent = new Intent(Intent.ACTION_CALL,
                            Uri.parse("tel:(+34)666777999"));
                }
                break;



            case R.id.btn_camara:
                intent = new Intent("android.media.action.IMAGE_CAPTURE");
                break;

            default:
                break;


        }

        startActivity(intent);

    }
}