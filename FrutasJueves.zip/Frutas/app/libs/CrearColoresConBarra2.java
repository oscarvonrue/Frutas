package com.example.ejercicioexamenrepaso;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView txtRed, txtGreen, txtBlue;
    SeekBar sbRed, sbGreen, sbBlue;
    ImageButton btnSaveRed, btnSaveGreen, btnSaveBlue;
    ImageView imgColor, imgComplementaryColor;

    SharedPreferences preferences;
    int red, green, blue;

    static final String RED = "red";
    static final String GREEN = "green";
    static final String BLUE = "blue";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtRed = findViewById(R.id.txtRed);
        txtGreen = findViewById(R.id.txtGreen);
        txtBlue = findViewById(R.id.txtBlue);

        sbRed = findViewById(R.id.sbRed);
        sbGreen = findViewById(R.id.sbGreen);
        sbBlue = findViewById(R.id.sbBlue);

        btnSaveRed = findViewById(R.id.btnSaveRed);
        btnSaveGreen = findViewById(R.id.btnSaveGreen);
        btnSaveBlue = findViewById(R.id.btnSaveBlue);

        imgColor = findViewById(R.id.imgColor);
        imgComplementaryColor = findViewById(R.id.imgComplementaryColor);

        preferences = getPreferences(MODE_PRIVATE);

        red = preferences.getInt(RED, 0);
        green = preferences.getInt(GREEN, 0);
        blue = preferences.getInt(BLUE, 0);

        sbRed.setProgress(red);
        sbGreen.setProgress(green);
        sbBlue.setProgress(blue);

        cambiarColor();

        setListeners(sbRed);
        setListeners(sbGreen);
        setListeners(sbBlue);

        setButtonListener(btnSaveRed, RED);
        setButtonListener(btnSaveGreen, GREEN);
        setButtonListener(btnSaveBlue, BLUE);
    }

    private void setListeners(SeekBar bar) {
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                cambiarColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void setButtonListener(ImageButton button, String color) {
        button.setOnClickListener(v -> {
            preferences = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            switch (color) {
                case RED:
                    editor.putInt(RED, sbRed.getProgress());
                    Toast.makeText(this, "Red saved", Toast.LENGTH_SHORT).show();
                    break;
                case GREEN:
                    editor.putInt(GREEN, sbGreen.getProgress());
                    Toast.makeText(this, "Green saved", Toast.LENGTH_SHORT).show();
                    break;
                case BLUE:
                    editor.putInt(BLUE, sbBlue.getProgress());
                    Toast.makeText(this, "Blue saved", Toast.LENGTH_SHORT).show();
                    break;
            }
            editor.commit();
        });
    }

    //Este metodo generaliza el cambio de color al deslizar las seekbars
    public void cambiarColor() {
        red = sbRed.getProgress();
        green = sbGreen.getProgress();
        blue = sbBlue.getProgress();

        int color = 0xFF000000 | (red << 16) | (green << 8) | blue;

        imgColor.setBackgroundColor(color);

        int complementaryColor = 0xFF000000 | ((255 - red) << 16) | ((255 - green) << 8) | (255 - blue);

        imgComplementaryColor.setBackgroundColor(complementaryColor);

        txtRed.setText(String.format("#%02x",red));
        txtGreen.setText(String.format("#%02x",green));
        txtBlue.setText(String.format("#%02x",blue));
    }
}