package com.example.ejemplointent3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt_url;
    Button btn_browse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_url = (EditText) findViewById(R.id.edt_direccion);
        btn_browse = (Button) findViewById(R.id.btn_navegar);

        btn_browse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creamos el intent
                Intent intent = new Intent(MainActivity.this,
                        ActividadNavegador.class);
                //Añadimos el contenido del campo editable
                Bundle bundle = new Bundle();
                bundle.putString("direccion", edt_url.getText().toString());

                //Añadir la información al intent
                intent.putExtras(bundle);

                //Lanzamos la actividad
                startActivity(intent);
            }
        });
    }
}