package com.example.ejemplointent3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class ActividadNavegador extends AppCompatActivity {

    Button btn_finish;
    WebView web_browser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_navegador);

        btn_finish = (Button) findViewById(R.id.btn_terminar);
        web_browser = (WebView) findViewById(R.id.web_navegador);

        //Recogemos la información de la actividad principal
        Bundle bundle = getIntent().getExtras();

        web_browser.loadUrl(bundle.getString("direccion"));

        btn_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}