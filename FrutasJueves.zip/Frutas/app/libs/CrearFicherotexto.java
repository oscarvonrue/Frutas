package com.example.ejemploficheros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    EditText edt_text;
    Button btn_save, btn_load;
    TextView txt_output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_text = (EditText) findViewById(R.id.edt_texto);
        btn_save = (Button) findViewById(R.id.btn_guardar);
        btn_load = (Button) findViewById(R.id.btn_cargar);
        txt_output = (TextView) findViewById(R.id.txt_salida);


        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = edt_text.getText().toString();
                try {
                    //Creamos fichero
                    FileOutputStream fOut = openFileOutput("fichero.txt",
                            MODE_PRIVATE);

                    //Creamos flujo con fichero asociado
                    OutputStreamWriter osw = new OutputStreamWriter(fOut);

                    //Escribimos datos
                    osw.write(str);
                    osw.flush();
                    osw.close();

                    //Mostramos un mensaje de OK
                    Toast.makeText(getApplicationContext(),
                            "Fichero guardado",
                            Toast.LENGTH_SHORT).show();

                    edt_text.setText("");


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        btn_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}