package com.example.superejercicio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.Nullable;

public class PrimeraActividad extends AppCompatActivity {

    TextView txt_output;    // Texto cabecera


    EditText text_Nombre;       // Campos
    EditText text_Apellido;

    Button botonReturn;

    Button botonCuartaActividad;



    @Override                                                                                           // Cuando viene de la otra pantalla
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 4 && resultCode == RESULT_OK) {

           String info = data.getExtras().getString("info").toString();

            Toast.makeText(getApplicationContext(), info , Toast.LENGTH_LONG).show();





        }
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primera_actividad);


        txt_output = (TextView) findViewById(R.id.text_mandado);

        text_Nombre= (EditText) findViewById(R.id.edt_textNombre);
        text_Apellido = (EditText) findViewById(R.id.edt_textApellido);

        botonReturn = (Button) findViewById(R.id.btn_return);
        botonCuartaActividad=(Button) findViewById(R.id.btn_cuartaactividad);


        Bundle bundle = getIntent().getExtras();
        String texto = bundle.getString("textomandado").toString();
        txt_output.setText(texto);



     botonReturn.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             //Construimos la vuelta a partir del intent que llega
             Intent intent = getIntent();

             intent.putExtra("texto de nombre",text_Nombre.getText().toString());       // Cuidado al toString
             intent.putExtra("texto de apellido",text_Apellido.getText().toString());

             setResult(RESULT_OK, intent);

             finish();
         }
     });


     botonCuartaActividad.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent = new Intent (PrimeraActividad.this,CuartaActividad.class); // Creamos el intent
             // Añadimos el contenido del campo editable
             Bundle bundle = new Bundle();                                       // Creamos un objeto Bundle para poder enviar datos entre las actividades
             bundle.putString("textomandado", "Vengo desde el Home");                           // Etiqueta al valor que después quiero recuper // Métodos put y metodos get
             intent.putExtras(bundle);                                           // Asociar al intent
             // startActivity(intent);

             startActivityForResult(intent, 4);
         }
     });

    }
}