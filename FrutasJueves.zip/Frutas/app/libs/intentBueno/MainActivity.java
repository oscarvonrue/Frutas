package com.example.superejercicio;

import static com.example.superejercicio.R.id.radioButton_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.Nullable;

public class MainActivity extends AppCompatActivity {
                                                                                // Declaración de variables
    RadioGroup actividades;
    Button ir_actividades;
    TextView textoVuelta;

    String cadenaNombre="";
    String cadenaApellido="";

    @Override                                                                                           // Cuando viene de la otra pantalla
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);



        if (requestCode == 0 && resultCode == RESULT_OK) {

            textoVuelta=(TextView) findViewById(R.id.texto_Vuelta);
          cadenaNombre = data.getExtras().getString("texto de nombre").toString();                  // Cuidado al toString
          cadenaApellido = data.getExtras().getString("texto de apellido").toString();

          Toast.makeText(getApplicationContext(),"Vuelvo con " + cadenaNombre + " " + cadenaApellido, Toast.LENGTH_LONG).show();
          textoVuelta.setText("Has vuelto " + cadenaNombre +" " + cadenaApellido);


        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textoVuelta=(TextView) findViewById(R.id.texto_Vuelta);

                                                                                // Binding
        actividades = (RadioGroup) findViewById(R.id.radioGroup);
        ir_actividades = (Button) findViewById(R.id.button_irActividad);


        // Hacer cosas

        //Que vaya a las actividades

        ir_actividades.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Distinguir el radio seleccionado

                RadioButton radio1Seleccionado = (RadioButton) findViewById(radioButton_1);

                if(radio1Seleccionado.isChecked()){

                    Toast.makeText(getApplicationContext(),"Ha seleccionado ir a la Actividad 1", Toast.LENGTH_LONG).show();

                    //String texto= (String) radio1Seleccionado.getText();


                    Intent intent = new Intent (MainActivity.this,PrimeraActividad.class); // Creamos el intent
                    // Añadimos el contenido del campo editable
                    Bundle bundle = new Bundle();                                       // Creamos un objeto Bundle para poder enviar datos entre las actividades
                    bundle.putString("textomandado", "Vengo desde el Home");                           // Etiqueta al valor que después quiero recuper // Métodos put y metodos get
                    intent.putExtras(bundle);                                           // Asociar al intent
                   // startActivity(intent);

                    startActivityForResult(intent, 0);

                }

            }
        });



    }
}

// bundle.putString("direccion", texto);