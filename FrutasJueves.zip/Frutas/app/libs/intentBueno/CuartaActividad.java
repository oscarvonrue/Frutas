package com.example.superejercicio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CuartaActividad extends AppCompatActivity {

    Button returnButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuarta_actividad);

        returnButton=(Button) findViewById(R.id.btn_retorno);
        Toast.makeText(getApplicationContext(),"Estamos en la 4ª actividad", Toast.LENGTH_LONG).show();


        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Construimos la vuelta a partir del intent que llega
                Intent intent = getIntent();

                intent.putExtra("info","vengo de la 4ª actividad");

                setResult(RESULT_OK, intent);

                finish();
            }
        });

    }


}