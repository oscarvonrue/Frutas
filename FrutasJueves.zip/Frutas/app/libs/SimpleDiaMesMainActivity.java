package com.example.ejemplosjava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    TextView txt_mensaje;
    int mes=11;
    int year=2022;

    String

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_mensaje = (TextView) findViewById(R.id.txt_pantalla);


        String mensaje="El mes " + mes;
        int dias=0;

        switch (mes){
            case 1: case 3: case 5:
            case 7: case 8: case 10:
            case 12:
                dias=31;
                mensaje+= " tiene " + dias + " días.";
                break;
            case 2:
                dias=28;
                mensaje+= " tiene " + dias + " días.";
                break;
            case 4: case 6: case 9: case 11:
                dias= 30;
                mensaje+= " tiene " + dias + " días.";
                break;
            default:
                mensaje+= " no existe.";
        }


        escribirMensaje(mensaje);

    }

    private void escribirMensaje(String mensaje) {
        String message = mensaje;
        txt_mensaje.setText(message);
        txt_mensaje.setTextSize(25);

    }
}