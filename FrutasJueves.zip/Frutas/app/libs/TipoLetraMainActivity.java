package com.example.ejemploletragrande;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Type;

public class MainActivity extends AppCompatActivity {

    EditText edt_text;
    Button btn_large, btn_write;
    TextView txt_text;
    CheckBox chk_italic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_text = (EditText) findViewById(R.id.edt_texto);
        btn_large = (Button) findViewById(R.id.btn_grande);
        btn_write = (Button) findViewById(R.id.btn_escribe);
        txt_text = (TextView) findViewById(R.id.txt_texto);
        chk_italic = (CheckBox) findViewById(R.id.chk_cursiva);

        txt_text.setOn

        btn_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_text.setText(edt_text.getText().toString());

            }
        });

        btn_large.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_text.setTextSize(40);

            }
        });

        chk_italic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (chk_italic.isChecked()){
                    txt_text.setTypeface(null, Typeface.ITALIC);
                } else {
                    txt_text.setTypeface(null, Typeface.NORMAL);
                }
            }
        });


    }
}