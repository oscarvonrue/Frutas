package com.example.cuadrosdialogo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LetrasGrandes extends AppCompatActivity {

    EditText edt_input;
    Button btn_write, btn_size;
    TextView txt_output;
    String texto="";
    boolean large=true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_letras_grandes);

        //Referenciamos controles a los objetos
        edt_input = (EditText) findViewById(R.id.edt_entrada);
        btn_write = (Button) findViewById(R.id.btn_escribir);
        btn_size = (Button) findViewById(R.id.btn_grande);
        txt_output = (TextView) findViewById(R.id.txt_salida);

        btn_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                texto += edt_input.getText().toString() + "\n";
                txt_output.setText(texto);
                //O en una única línea:
                //txt_output.setText(edt_input.getText().toString());
            }
        });

        btn_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (large) {
                    txt_output.setTextSize(60);
                    large=false;
                    btn_size.setText("Pequeño");
                } else {
                    txt_output.setTextSize(20);
                    large=true;
                    btn_size.setText("Grande");
                }
            }
        });
    }
}