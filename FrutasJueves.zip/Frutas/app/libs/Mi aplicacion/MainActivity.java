package com.example.cuadrosdialogo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button boton1;  Button boton2; Button boton3; Button boton4; Button boton5;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boton1=(Button) findViewById(R.id.button_1);
        boton2=(Button) findViewById(R.id.button_2);
        boton3=(Button) findViewById(R.id.button_3);
        boton4=(Button) findViewById(R.id.button_4);
        boton5=(Button) findViewById(R.id.button_5);


        // Actividad 1
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Actividad1.class);
                startActivity(intent);
            }
        });


        // Cuadros Dialogo
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CuadrosDialogo.class);
                startActivity(intent);
            }
        });

        // Cuadros Dialogo
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LetrasGrandes.class);
                startActivity(intent);
            }
        });

        // Cuadros Dialogo
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Seekbar.class);
                startActivity(intent);
            }
        });

        // Cuadros Dialogo
        boton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EcribirEnFicheroTXT.class);
                startActivity(intent);
            }
        });
    }
}

/*
Para hacer la apk
https://code.tutsplus.com/es/tutorials/how-to-generate-apk-and-signed-apk-files-in-android-studio--cms-37927

 */