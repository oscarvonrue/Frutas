package com.example.cuadrosdialogo;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class EcribirEnFicheroTXT extends AppCompatActivity {
    private Context context;
    EditText edt_text;
    Button btn_save, btn_load;
    TextView txt_output;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecribir_en_fichero_txt);

        edt_text = (EditText) findViewById(R.id.editTextTextPersonName2);
        btn_save = (Button) findViewById(R.id.btn_guardarr);
        btn_load = (Button) findViewById(R.id.btn_cargar);
        txt_output = (TextView) findViewById(R.id.txt_salida);


        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { // Hacer que se meta una linea entre el texto

                String str = edt_text.getText().toString();
                try {
                    //Creamos fichero
                    FileOutputStream fOut = openFileOutput("fichero.txt",
                            MODE_PRIVATE);

                    //Creamos flujo con fichero asociado
                    OutputStreamWriter osw = new OutputStreamWriter(fOut);

                    //Escribimos datos
                    osw.write(str);
                    osw.flush();
                    osw.close();

                    //Mostramos un mensaje de OK
                    Toast.makeText(getApplicationContext(),"Fichero guardado",
                            LENGTH_SHORT).show();

                    edt_text.setText("");


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });


        // Leer desde la memoria interna   // Ampliar a memoria Sd
        btn_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //https://www.youtube.com/watch?v=m6NVVGOQk0s
                try{
                    BufferedReader aux = new BufferedReader(new InputStreamReader(openFileInput("fichero.txt")));
                    String texto = aux.readLine();


                    while(texto != null){
                        Toast.makeText(getApplicationContext(),"Texto del archivo" + texto, Toast.LENGTH_SHORT).show();
                        texto = aux.readLine();
                    }

                }catch (Exception e){
                    Log.e("Archivo", "Error al leer archivo desde la memoria interna");
                }
            }


        });
    }
}

/* Para targeta de memoria http://www.jtech.ua.es/cursos/apuntes/moviles/daa2013/sesion06-apuntes.html
* try {
    File raiz = Environment.getExternalStorageDirectory();
    if (raiz.canWrite()){
        File file = new File(raiz, "fichero.txt");
        BufferedWriter out = new BufferedWriter(new FileWriter(file));
        out.write("Mi texto escrito desde Android");
        out.close();
    }
} catch (IOException e) {
    Log.e("FILE I/O", "Error en la escritura de fichero: " + e.getMessage());
}
* */