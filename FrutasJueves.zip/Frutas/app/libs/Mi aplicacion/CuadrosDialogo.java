package com.example.cuadrosdialogo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class CuadrosDialogo extends AppCompatActivity {

    Button btn_dialog_1;
    Button btn_dialog_2;

    CharSequence[] items= {"Opción 1" ,"Opción 2", "Opción 3"};
    boolean[] itemsChecked = new boolean[items.length];

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuadros_dialogo);

        btn_dialog_1 = findViewById(R.id.btn_dialogo_1);
        btn_dialog_2 = findViewById(R.id.btn_dialogo_2);


        btn_dialog_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(1);
            }
        });

        btn_dialog_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(2);
            }
        });

    }

    @Override
    protected Dialog onCreateDialog(int id) {

        switch (id){
            case 1:
                return  new AlertDialog.Builder(this)
                        .setIcon(R.mipmap.ic_launcher)
                        .setTitle("Error Crítico")
                        .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),"Has hecho ", Toast.LENGTH_SHORT).show();

                            }
                        })

                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),"Has hecho en cancelar", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setMessage("Hola Corazones!!!")
                        .create();


            case 2:
                return  new AlertDialog.Builder(this)
                        .setIcon(R.mipmap.ic_launcher)
                        .setTitle("Error Crítico")
                        .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),"Has hecho ", Toast.LENGTH_SHORT).show();

                            }
                        })

                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(),"Has hecho en cancelar", Toast.LENGTH_SHORT).show();
                            }
                        })
                        // .setMessage("Elige una opción y pulsa aceptar!!!") // No pueden convivir con el de abajo, si no vista customizada un XML textView   ver en developers cuadros de dialogo sencillos

                        .setMultiChoiceItems(items, itemsChecked, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                                Toast.makeText(getApplicationContext(),"Has hecho " + items[i] , Toast.LENGTH_SHORT).show();
                            }
                        })

                        .create();
        } // fin switch

        return null;
    }
}