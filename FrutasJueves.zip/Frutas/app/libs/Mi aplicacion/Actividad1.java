package com.example.cuadrosdialogo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Actividad1 extends AppCompatActivity {

    EditText edt_text;
    CheckBox chk_large;
    RadioGroup rdg_colors;

    RadioButton radio_rojo;
    RadioButton radio_amarillo;
    RadioButton radio_verde;

    String colorAlmacenado="";

    Button btn_volver;

    String color="";



    Button btn_large, btn_write;
    CheckBox chk_italic;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad1);

                                                                    // Binding
        edt_text =(EditText) findViewById(R.id.edt_texto);
        chk_large =(CheckBox) findViewById(R.id.chk_grande);
        rdg_colors = (RadioGroup) findViewById(R.id.rg_colores);

        radio_rojo = (RadioButton) findViewById(R.id.radioButton_rojo);
        radio_amarillo = (RadioButton) findViewById(R.id.radioButton_amarillo);
        radio_verde = (RadioButton) findViewById(R.id.radioButton_verde);

        btn_volver=(Button) findViewById(R.id.button_volver);


        //btn_large = (Editext) findViewById(R.id.btn_grande);
        btn_write = (Button) findViewById(R.id.btn_escribe);

        chk_italic= (CheckBox) findViewById(R.id.checkBox2);




        chk_large.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if( compoundButton.isChecked()){
                    edt_text.setTextSize(40);
                }else{
                    edt_text.setTextSize(20);
                }
            }
        }); // Fin checked checkbox Listener


        rdg_colors.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                RadioButton rdb = (RadioButton) findViewById(checkedId);
                //colorAlmacenado=rdb.getText().toString();
               color = ponerColor();

                   Context context = getApplicationContext();
                    CharSequence text = color;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }); // Fin checked Radios Listener

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        btn_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               edt_text.setText(edt_text.getText().toString());
                if(chk_italic.isChecked()){
                    edt_text.setTypeface(null, Typeface.ITALIC);

                }else{
                    edt_text.setTypeface(null, Typeface.NORMAL);

                }
            }
        });







    } // Fin OnCreate


    private String ponerColor() {

        int checkedId = ((RadioGroup) findViewById(R.id.rg_colores)).getCheckedRadioButtonId();
        if (checkedId == -1) {
            // Toast.makeText(getApplicationContext(),"Vacios", Toast.LENGTH_SHORT).show();
            return "";
        } else {

            switch (checkedId) {
                case R.id.radioButton_rojo:
                    edt_text.setBackgroundColor(Color.RED);
                   color= "Rojo";
                break;

                case R.id.radioButton_amarillo:
                    edt_text.setBackgroundColor(Color.YELLOW);
                    color= "Amarillo";
                break;

                case R.id.radioButton_verde:
                    edt_text.setBackgroundColor(Color.GREEN);
                    color= "Verde";
                break;
            }

        } // fin del if
        return color;
    }

}   // Fin MainActivity


/*
 rdg_colors.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup,
                                         int checkedId) {
                RadioButton rdb = (RadioButton) findViewById(checkedId);
                poner_color (rdb.getText().toString());

            }
        });
    }

    private void poner_color(String color) {
        switch (color) {
            case "Rojo":
                edt_text.setBackgroundColor(Color.RED);
                break;
            case "Verde":
                edt_text.setBackgroundColor(Color.GREEN);
                break;
            case "Azul":
                edt_text.setBackgroundColor(Color.BLUE);
                break;
            default:
                break;
        }

    }
* */