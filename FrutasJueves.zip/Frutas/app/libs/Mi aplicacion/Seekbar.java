package com.example.cuadrosdialogo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

public class Seekbar extends AppCompatActivity {

    SeekBar skb_bar;
    EditText edt_text;
    Button btn_save;

    SharedPreferences preferencias;
    String prefNombre;
    int progreso;

    static final String FONT_SIZE_KEY = "tamaño_fuente";
    static final String TEXT_VALUE_KEY = "valor_texto";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seekbar);


        skb_bar = (SeekBar) findViewById(R.id.skb_barra);
        edt_text = (EditText) findViewById(R.id.editTextTextPersonName);
        btn_save = (Button) findViewById(R.id.btn_guardar);

        preferencias = getPreferences(MODE_PRIVATE);

        float fontSize = preferencias.getFloat(FONT_SIZE_KEY, 40);
        skb_bar.setProgress((int) fontSize-20);

        String texto = preferencias.getString(TEXT_VALUE_KEY, "Pon tu texto aquí");
        edt_text.setText(texto);
        edt_text.setTextSize(fontSize);

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);

                SharedPreferences.Editor editor = preferencias.edit();

                editor.putFloat(FONT_SIZE_KEY, (float) progreso);
                editor.putString(TEXT_VALUE_KEY, edt_text.getText().toString());

                editor.commit();

                Toast.makeText(getApplicationContext(),"Los datos se han guardado", Toast.LENGTH_LONG).show();
            }
        });

        skb_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progreso = progress + 20;
                edt_text.setTextSize(progreso);


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}