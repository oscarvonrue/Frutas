package com.example.crear_colores;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar skb_bar1,skb_bar2,skb_bar3;
    ImageView imagen1,imagen2;
    ImageView guardar_red,guardar_green,guardar_blue;
    TextView hexa_r,hexa_g,hexa_b;

    static final int max=255;
    static final int min=0;
    int red=0,green=0,blue=0;
    String hexadecimal_red,hexadecimal_green,hexadecimal_blue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        skb_bar1=(SeekBar) findViewById(R.id.seekBar_1);
        skb_bar2=(SeekBar) findViewById(R.id.seekBar_2);
        skb_bar3=(SeekBar) findViewById(R.id.seekBar_3);

        imagen1=(ImageView) findViewById(R.id.imagen_1);
        imagen2=(ImageView) findViewById(R.id.imagen_2);

        guardar_red=(ImageView) findViewById(R.id.rojo);
        guardar_green=(ImageView) findViewById(R.id.verde);
        guardar_blue=(ImageView) findViewById(R.id.azul);

        hexa_r=(TextView) findViewById(R.id.r);
        hexa_g=(TextView) findViewById(R.id.g);
        hexa_b=(TextView) findViewById(R.id.b);

        guardar_red.setBackgroundColor(Color.RED);
        guardar_green.setBackgroundColor(Color.GREEN);
        guardar_blue.setBackgroundColor(Color.BLUE);

        skb_bar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                red=progress;

                hexadecimal_red=Integer.toHexString(red);
                hexa_r.setText(hexadecimal_red.toString());

                imagen1.setBackgroundColor(Color.argb(255,red,green,blue));
                imagen2.setBackgroundColor(Color.argb(255,max-red,max-green,max-blue));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skb_bar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                green=progress;

                hexadecimal_green=Integer.toHexString(green);
                hexa_g.setText(hexadecimal_green.toString());

                hexadecimal_green=Integer.toHexString(green);
                imagen1.setBackgroundColor(Color.argb(255,red,green,blue));
                imagen2.setBackgroundColor(Color.argb(255,max-red,max-green,max-blue));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skb_bar3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                blue=progress;

                hexadecimal_blue=Integer.toHexString(blue);
                hexa_b.setText(hexadecimal_blue.toString());

                hexadecimal_blue=Integer.toHexString(blue);
                imagen1.setBackgroundColor(Color.argb(255,red,green,blue));
                imagen2.setBackgroundColor(Color.argb(255,max-red,max-green,max-blue));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


}