package com.example.frutas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MezclaColoresActivity extends AppCompatActivity {

    TextView txtRed, txtGreen, txtBlue;
    SeekBar sbRed, sbGreen, sbBlue;
    ImageButton btnSaveRed, btnSaveGreen, btnSaveBlue;
    ImageView imgColor, imgComplementaryColor;

    Button cargarUltimo;

    SharedPreferences preferences;
    static final String RED = "red";
    static final String GREEN = "green";
    static final String BLUE = "blue";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mezcla_colores);


        txtRed = findViewById(R.id.txtRed);
        txtGreen = findViewById(R.id.txtGreen);
        txtBlue = findViewById(R.id.txtBlue);

        sbRed = findViewById(R.id.sbRed);
        sbGreen = findViewById(R.id.sbGreen);
        sbBlue = findViewById(R.id.sbBlue);

        btnSaveRed = findViewById(R.id.btnSaveRed);
        btnSaveGreen = findViewById(R.id.btnSaveGreen);
        btnSaveBlue = findViewById(R.id.btnSaveBlue);

        imgColor = findViewById(R.id.imgColor);
        imgComplementaryColor = findViewById(R.id.imgComplementaryColor);

        cargarUltimo=findViewById(R.id.button_cargarultimo);


        btnSaveRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarPreferencias();
            }
        });

        btnSaveGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarPreferencias();
            }
        });

        btnSaveBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarPreferencias();
            }
        });


        cargarUltimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarPreferencias();
            }
        });





        sbRed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                modificar(); }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        sbGreen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                modificar();
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        sbBlue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                modificar();
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });


    }

    ///////////////////Funciona, si ocurre algo externo a la actividad, ejemplo al girar pantalla o te llamen
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        //https://medium.com/@shobhith/onsaveinstancestate-and-onrestoreinstancestate-in-android-c29f22b0ef4e
        super.onSaveInstanceState(savedInstanceState);
        /*// Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.
        savedInstanceState.putBoolean("MyBoolean", true);
        savedInstanceState.putDouble("myDouble", 1.9);
        savedInstanceState.putInt("MyInt", 1);
        savedInstanceState.putString("MyString", "Welcome back to Android");*/
        savedInstanceState.putInt("valorRed_resOnsave", 50);
        Toast.makeText(getApplicationContext(), "onSaveInstanceState" , Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
       /* // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.
        boolean myBoolean = savedInstanceState.getBoolean("MyBoolean");
        double myDouble = savedInstanceState.getDouble("myDouble");
        int myInt = savedInstanceState.getInt("MyInt");
        String myString = savedInstanceState.getString("MyString");

        */
        Toast.makeText(getApplicationContext(),"onRestorateInstanceState" , Toast.LENGTH_LONG).show();
        int red_onsaveinstance = savedInstanceState.getInt("valorRed_resOnsave");
        sbRed.setProgress(red_onsaveinstance);
    }
    ////////////////////////////////














    private void cargarPreferencias() {
        preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        int red = preferences.getInt(RED, 0);
        sbRed.setProgress(red);

        int green = preferences.getInt(GREEN, 0);
        sbGreen.setProgress(green);

        int blue = preferences.getInt(BLUE, 0);
        sbBlue.setProgress(blue);

    }


    public void modificar() {
        int red = sbRed.getProgress();
        int green= sbGreen.getProgress();
        int blue = sbBlue.getProgress();

        int color = 0xFF000000 | (red << 16) | (green << 8) | blue;
        //imgColor.setBackgroundColor(color);
        imgColor.setBackgroundColor(Color.rgb(red, green, blue));

        int complementaryColor = 0xFF000000 | ((255 - red) << 16) | ((255 - green) << 8) | (255 - blue);
        imgComplementaryColor.setBackgroundColor(complementaryColor);

        String hexColor_red = String.format("#%02X", (0xFFFFFF & red));
        txtRed.setText(hexColor_red);

        String hexColor_green = String.format("#%02X", (0xFFFFFF & green));
        txtGreen.setText(hexColor_green);

        String hexColor_blue = String.format("#%02X", (0xFFFFFF & blue));
        txtBlue.setText(hexColor_blue);
        //imgColor.setBackgroundColor(Color.parseColor("#FFFFAA"));
    }

    public void guardarPreferencias(){
        preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        editor.putInt(RED, sbRed.getProgress());
        editor.putInt(GREEN, sbGreen.getProgress());
        editor.putInt(BLUE, sbBlue.getProgress());
        // editor.putFloat(FONT_SIZE_KEY, (float) progreso);
        editor.commit();

    }




}