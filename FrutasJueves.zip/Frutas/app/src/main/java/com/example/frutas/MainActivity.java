package com.example.frutas;

import static android.app.PendingIntent.getActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    SharedPreferences preferencias;

    ImageView frutas, imageManzana, imagePera, imageNaranja, imageUva, imagePlatano;

    TextView textManzanas, textPlatanos, textNaranjas, textUvas, textPeras;

    int manzana=0, pera=0, platano=0, naranja=0, uva=0;

    Button anadirpreferencias, extraerpreferencias, anadirtexto, anadir_basededatos;
    Button extraerDatosdesdeArchivoTexto, leer_basedatos, borrar;


    EditText caja_TotalManzanas, caja_TotalPlatanos, caja_TotalNaranjas, caja_TotalUvas, caja_TotalPeras;


    //Añadir las preferencias

    static final String MANZANAS = "manzanas";
    static final String PLATANOS = "platanos";
    static final String NARANJAS = "naranjas";
    static final String UVAS = "uvas";
    static final String PERAS = "peras";


    DBAdapter db = new DBAdapter(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        frutas= (ImageView) findViewById(R.id.imageView_frutas);
        imageManzana= (ImageView) findViewById(R.id.imageView_manzana);
        imagePlatano= (ImageView) findViewById(R.id.imageView_platano);
        imageNaranja= (ImageView) findViewById(R.id.imageView_naranja);
        imageUva= (ImageView) findViewById(R.id.imageView_uva);
        imagePera= (ImageView) findViewById(R.id.imageView_pera);

        ///
        textManzanas=(TextView)findViewById(R.id.textView_manzanas);
        textPlatanos=(TextView)findViewById(R.id.textView_platanos);
        textNaranjas=(TextView)findViewById(R.id.textView_naranjas);
        textUvas=(TextView)findViewById(R.id.textView_uvas);
        textPeras=(TextView)findViewById(R.id.textView_peras);
        ///

        caja_TotalManzanas=(EditText) findViewById(R.id.caja_manzanasTotal);
        caja_TotalPlatanos=(EditText) findViewById(R.id.caja_platanosTotal);
        caja_TotalNaranjas=(EditText) findViewById(R.id.caja_naranjasTotal);
        caja_TotalUvas=(EditText) findViewById(R.id.caja_uvasTotal);
        caja_TotalPeras=(EditText) findViewById(R.id.caja_perasTotal);

        anadirpreferencias=(Button) findViewById(R.id.button_preferencias);
        extraerpreferencias=(Button) findViewById(R.id.button_getpreferencias);

        anadirtexto=(Button) findViewById(R.id.button_anadirtexto);
        extraerDatosdesdeArchivoTexto = (Button) findViewById(R.id.button_extraerdesdearchivo);

        anadir_basededatos=(Button) findViewById(R.id.button_anadirbasededatos);
        leer_basedatos=(Button) findViewById(R.id.button_leerbasedatos);

        borrar=(Button)  findViewById(R.id.button_borrar);


    //Borrar los campos
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                caja_TotalManzanas.setText(""); textManzanas.setText("");
                caja_TotalPlatanos.setText(""); textPlatanos.setText("");
                caja_TotalNaranjas.setText(""); textNaranjas.setText("");
                caja_TotalUvas.setText("");     textUvas.setText("");
                caja_TotalPeras.setText("");    textPeras.setText("");
            }
        });


    // BOTON LEER BASE DE DATOS
        leer_basedatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.open();
                Cursor cursor = db.consultar_todos();
                    if (cursor.moveToFirst()) {
                        do {
                            //String id= cursor.getString(0);
                           String manzanas = cursor.getString(1); caja_TotalManzanas.setText(manzanas);
                           String platanos= cursor.getString(2);  caja_TotalPlatanos.setText(platanos);
                           String naranjas= cursor.getString(3);  caja_TotalNaranjas.setText(naranjas);
                           String uvas = cursor.getString(4);  caja_TotalUvas.setText(uvas);
                           String peras = cursor.getString(5);  caja_TotalPeras.setText(peras);
                        } while(cursor.moveToPrevious());
                    }
            }
        });



// Añade a la base de datos el registro, borrando todooo antes
        anadir_basededatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int manzanas= Integer.parseInt(caja_TotalManzanas.getText().toString());
                int platanos= Integer.parseInt(caja_TotalPlatanos.getText().toString());
                int naranjas= Integer.parseInt(caja_TotalNaranjas.getText().toString());
                int uvas= Integer.parseInt(caja_TotalUvas.getText().toString());
                int peras= Integer.parseInt(caja_TotalPeras.getText().toString());
                // Comprobar que no esté vacio que peta

                if(caja_TotalManzanas.getText().toString()=="") {manzanas=0;}
                if(caja_TotalPlatanos.getText().toString()=="") {platanos=0;}
                if(caja_TotalNaranjas.getText().toString()=="") {naranjas=0;}
                if(caja_TotalUvas.getText().toString()=="") {uvas=0;}
                if(caja_TotalPeras.getText().toString()=="") {peras=0;}


                db.open();
                db.borrar_TodasFrutas();
                db.insertar_frutas(manzanas, platanos, naranjas, uvas, peras);
            }
        });


        preferencias = getPreferences(MODE_PRIVATE);
        anadirpreferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numManzanas = textManzanas.getText().toString();
                Toast.makeText(getApplicationContext(),numManzanas , Toast.LENGTH_LONG).show();

                //Inserción de Preferencias
                   SharedPreferences.Editor editor = preferencias.edit();
                    editor = preferencias.edit();

                    editor.putString(MANZANAS, textManzanas.getText().toString());
                    editor.putString(PLATANOS, textPlatanos.getText().toString());
                    editor.putString(NARANJAS, textNaranjas.getText().toString());
                    editor.putString(UVAS, textUvas.getText().toString());
                    editor.putString(PERAS,textPeras.getText().toString());
                    // editor.putFloat(FONT_SIZE_KEY, (float) progreso);
                    editor.commit();

                       /* Toast.makeText(getApplicationContext(), "Añadido: "
                        + textManzanas.getText() + " manzana/s, "
                        + textPlatanos.getText() + " platano/s, "
                        + textNaranjas.getText() + " naranja/s, "
                        + textUvas.getText() + " uva/s, "
                        + textPeras.getText() + " pera/s, " , Toast.LENGTH_LONG).show();*/
                //////
            }
        });

    // Extrae las preferencias
        extraerpreferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);

                String ultimo_manzanas = preferencias.getString(MANZANAS, "");
                caja_TotalManzanas.setText(ultimo_manzanas);

                String ultimo_platanos = preferencias.getString(PLATANOS, "");
                caja_TotalPlatanos.setText(ultimo_platanos);

                String ultimo_naranjas = preferencias.getString(NARANJAS, "");
                caja_TotalNaranjas.setText(ultimo_naranjas);

                String ultimo_uvas = preferencias.getString(UVAS, "");
                caja_TotalUvas.setText(ultimo_uvas);

                String ultimo_peras = preferencias.getString(PERAS, "");
                caja_TotalPeras.setText(ultimo_peras);
            }
        });

        
        
    // Crea un fichero de texto
        anadirtexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Comprobar que no está vacio la caja del nombre de fichero
                // String nombreFichero = caja_nombreFichero.getText().toString();
                String nombreFichero="lofruitis";

                    try {
                        OutputStreamWriter fout = new OutputStreamWriter(openFileOutput(nombreFichero + ".txt", Context.MODE_PRIVATE));

                        String manzanas= caja_TotalManzanas.getText().toString();
                        String platanos= caja_TotalPlatanos.getText().toString();
                        String naranjas= caja_TotalNaranjas.getText().toString();
                        String uvas= caja_TotalUvas.getText().toString();
                        String peras= caja_TotalPeras.getText().toString();

                        String registros = manzanas + ";" + platanos + ";" + naranjas + ";" + uvas + ";" + peras + "\n";
                        fout.write(registros);

                        fout.close();
                        Toast.makeText(getApplicationContext(),"Fichero generado", Toast.LENGTH_SHORT).show();

                    } catch (Exception ex) {
                        Log.e("Ficheros", "Error al escribir fichero a memoria interna");
                    }
            }
        });

    // Lee desde fichero texto
        extraerDatosdesdeArchivoTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String desdefichero= String.valueOf(fichero.getText());  // el que yo diga
                try{
                    BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput("lofruitis.txt")));
                    String lineaTexto;

                    while ((lineaTexto = fin.readLine()) != null) {
                        String  trozos [] =  lineaTexto.split(";");
                        //String id = trozos[0];
                        String manzanas= trozos[0];  caja_TotalManzanas.setText(manzanas);
                        String platanos= trozos[1];  caja_TotalPlatanos.setText(platanos);
                        String naranjas= trozos[2];  caja_TotalNaranjas.setText(naranjas);
                        String uvas= trozos[3];      caja_TotalUvas.setText(uvas);
                        String peras= trozos[4];     caja_TotalPeras.setText(peras);
                    }
                    Toast.makeText(getApplicationContext(),"Datos extraidos desde fruitis.txt", Toast.LENGTH_SHORT).show();
                    fin.close();
                }
                catch (Exception ex)
                {
                    Log.e("Ficheros", "Error al leer fichero desde memoria interna");
                    // Toast.makeText(getApplicationContext(),"No ", Toast.LENGTH_SHORT).show();
                }
            }
        });




/* Se sustituye por el método "cargar_fruta"
        imageManzana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //frutas.setImageDrawable(null);
                frutas.setImageResource(R.drawable.manzana);
                manzana++;
                textManzanas.setText("" + manzana);
            }
        });
    etc....platano
*/




    }// fin onCreate



//////////////////////////////////////////////////////////////////////////////////////////////////              Menu e items
    //resourcesFile--->menu
    // Necesario para mostrar el menú
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }


    // Items del menú a un clic
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        DBAdapter db = new DBAdapter(this);

        switch (item.getItemId()) {
            case R.id.item_ejerciciocolores:
                Intent intent = new Intent(MainActivity.this, MezclaColoresActivity.class);
                startActivity(intent);
            break;

            case R.id.item_repasopreferencias:
                intent = new Intent(MainActivity.this, RepasoPreferenciasActivity.class);
                startActivity(intent);
            break;

            case R.id.item_webBroser:
                intent = new Intent(MainActivity.this, WebbrowserActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
/////////////////////////////////////////////////////////////////////////////////////////////////


    //Metodo que lo comparten varios botones
    public void cargar_fruta(View view) {
        switch (view.getId()){
            case R.id.imageView_manzana:
                frutas.setImageResource(R.drawable.manzana); manzana++; textManzanas.setText("" + manzana);
                showDialog(1); break;

            case R.id.imageView_platano:
                frutas.setImageResource(R.drawable.platano); platano++; textPlatanos.setText("" + platano);
                showDialog(2); break;

            case R.id.imageView_naranja:
                frutas.setImageResource(R.drawable.naranja); naranja++; textNaranjas.setText("" + naranja);
                showDialog(4); break;

            case R.id.imageView_uva:
                frutas.setImageResource(R.drawable.uva); uva++; textUvas.setText("" + uva);
                showDialog(5); break;

            case R.id.imageView_pera:

                frutas.setImageResource(R.drawable.pera); pera++; textPeras.setText("" + pera);
                showDialog(3);
                break;
        }
    }


    // Controlador de Dialogos
    // CuadrosDialogoMainActivity en carpeta libs
    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialogo = null;
        switch (id) {
            case 1: dialogo = manzana(); break;
            case 2: dialogo = platano(); break; case 3: dialogo = platanoAdvertencia(); break;
            case 4: dialogo = naranjaLogin(); break;
            case 5: dialogo = uvaOpciones(); break;
            //case 6: dialogo = uvaOpciones2(); break; con radios
            default:   break;
        }
        return dialogo;
    }


    private Dialog manzana() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Aviso")
                .setMessage("Hay seleccionado manzana")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Se cierra el cuadro de diálogo
                        dialog.cancel();
                    }
                });
        return builder.create();
    }
    private Dialog platano() {
        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Error crítico")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(3);
                    }
                })
                .setMessage("¿Desea borrar todos los datos?")
                .create();
    }
    private Dialog platanoAdvertencia() {
        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Advertencia")
                //.setView(R.layout.dialog_warning)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .create();

    }
    private Dialog naranjaLogin() {
        //Recoger el layout inflater
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_login, null);
        //Declarar objetos y referenciar con controles
        EditText edt_user, edt_password;
        edt_user = (EditText) dialogView.findViewById(R.id.edt_usuario);
        edt_password = (EditText) dialogView.findViewById(R.id.edt_contrasena);

        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Login")
                .setView(dialogView)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        /*Toast.makeText(getApplicationContext(),
                                "El usuario es "
                                        + edt_user.getText().toString()
                                        + " y su contraseña es "
                                        + edt_password.getText().toString(),
                                Toast.LENGTH_SHORT).show();*/
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(3);
                    }
                })
                .create();
    }
    CharSequence[] items = {"Opción 1", "Opción 2", "Opción 3", "Opción 4"};
    boolean[] itemsChecked = new boolean[items.length];
    private Dialog uvaOpciones() {

        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Cuadro diálogo opciones")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(3);
                    }
                })
                .setMultiChoiceItems(items,
                        itemsChecked,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface,
                                                int which,
                                                boolean isChecked) {
                                Toast.makeText(getApplicationContext(),
                                        "Has hecho clic en " + items[which]
                                                + " y lo has " + (isChecked?" marcado": " desmarcado"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        })
                .create();
    }

    public AlertDialog createRadioListDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());

        final CharSequence[] items = new CharSequence[3];

        items[0] = "Soltero/a";
        items[1] = "Casado/a";
        items[2] = "Divorciado/a";

        builder.setTitle("Estado Civil")
                .setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(
                                        getApplicationContext(),
                                        "Seleccionaste: " + items[which],
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                });

        return builder.create();
    }

    private Dialog uvaOpciones2() {
//https://www.develou.com/como-crear-dialogos-en-android/
        return new AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle("Cuadro diálogo opciones")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Aceptar",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),
                                "Has hecho clic en Cancelar",
                                Toast.LENGTH_SHORT).show();
                        showDialog(3);
                    }
                })
                .setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(
                                        getApplicationContext(),
                                        "Seleccionaste: " + items[which],
                                        Toast.LENGTH_SHORT)
                                .show();
                    }
                })
                .create();
    }
}

//https://www.develou.com/como-crear-dialogos-en-android/  para cuadros de diálogo