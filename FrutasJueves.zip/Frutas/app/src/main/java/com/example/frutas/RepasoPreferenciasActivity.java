package com.example.frutas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

public class RepasoPreferenciasActivity extends AppCompatActivity {

    EditText caja;
    SeekBar barraRed, barraGreen, barraBlue;
    SeekBar barraFuente;
    SeekBar barraTamano;

    RadioGroup groupfuente;
    RadioButton fuente1, fuente2, fuente3;

    int valorRed=0; int valorGreen=0; int valorBlue=0; int valorTamano=0;
    String valorFuente="";

    SharedPreferences preferencias;

    static final String COLORRED = "colorred";
    static final String COLORGREEN = "colorgreen";
    static final String COLORBLUE = "colorblue";

    static final String FUENTE = "fuente";
    static final String TAMANO = "tamano";

    static final String TEXTO = "texto";



    Button salvarColor, cargarColor, salvarTamano, cargarTamano, cargarFuente, salvarFuente, cargarTexto, salvarTexto, salvarTodo, cargarTodo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repaso_preferencia);

        caja=(EditText)findViewById(R.id.editText_caja);

        barraRed=(SeekBar) findViewById(R.id.seekBar_red);
        barraGreen=(SeekBar) findViewById(R.id.seekBar_green);
        barraBlue=(SeekBar) findViewById(R.id.seekBar_blue);

        barraTamano=(SeekBar) findViewById(R.id.seekBar_tamano);

        groupfuente=(RadioGroup) findViewById(R.id.radioGroup_fuente);
        fuente1=(RadioButton) findViewById(R.id.radioButton);
        fuente2=(RadioButton) findViewById(R.id.radioButton2);
        fuente3=(RadioButton) findViewById(R.id.radioButton3);

        salvarColor=(Button) findViewById(R.id.button_guardarcolor);
        cargarColor=(Button) findViewById(R.id.button_cargarcolor);

        salvarTamano=(Button) findViewById(R.id.button_salvartamano);
        cargarTamano=(Button) findViewById(R.id.button_cargartamano);

        salvarFuente=(Button) findViewById(R.id.button_salvarfuente);
        cargarFuente=(Button) findViewById(R.id.button_cargarfuente);

        salvarTexto=(Button) findViewById(R.id.button_salvartexto);
        cargarTexto=(Button) findViewById(R.id.button_cargartexto);


        salvarTodo=(Button) findViewById(R.id.button_salvartodo);
        cargarTodo=(Button) findViewById(R.id.button_cargartodo);




        barraRed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                 valorRed = barraRed.getProgress(); cambiarColor();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        barraGreen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valorGreen = barraGreen.getProgress();  cambiarColor();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {  }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        barraBlue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valorBlue = barraBlue.getProgress();  cambiarColor();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });


    // Barra de Tamaño
    barraTamano.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valorTamano = barraTamano.getProgress();
                cambiarTamano();
            }

            @Override  public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });


// Radios de tipo de fuente
        groupfuente.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                String fuente="";
                    switch (checkedId) {
                        case R.id.radioButton: valorFuente ="shojumaru"; break;
                        case R.id.radioButton2: valorFuente ="leckerli"; break;
                        case R.id.radioButton3:  valorFuente ="newrocker"; break;
                    }
            }
        });



        salvarColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor = preferencias.edit();
                editor.putInt(COLORRED, valorRed);
                editor.putInt(COLORGREEN, valorGreen);
                editor.putInt(COLORBLUE, valorBlue);
                // editor.putFloat(FONT_SIZE_KEY, (float) progreso);
                editor.commit();
            }
        });
        cargarColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                int ultimo_red = preferencias.getInt( COLORRED, 0);
                barraRed.setProgress(ultimo_red);

                int ultimo_green = preferencias.getInt( COLORGREEN, 0);
                barraGreen.setProgress(ultimo_green);

                int ultimo_blue = preferencias.getInt( COLORBLUE, 0);
                barraBlue.setProgress(ultimo_blue);


                // RECOGER LOS COLORES Y AL TEXTO
                int color =  0xFF000000 | (ultimo_red << 16) | (ultimo_green << 8) | ultimo_blue;
                //caja.setTextColor(Color.rgb(ultimo_red, ultimo_green, ultimo_blue));/
                caja.setTextColor(color);
            }
        });

        //// Preferencias TAMAÑO
        salvarTamano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor = preferencias.edit();
                editor.putInt(TAMANO, valorTamano);
                editor.commit();
            }
        });
        cargarTamano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                int ultimo_tamano = preferencias.getInt( TAMANO, 0);
                barraTamano.setProgress(ultimo_tamano);
            }
        });
        /////////////////////


// Cargar Tipos de letras, sus archivos se dejan en la carpeta fonts
        salvarFuente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor = preferencias.edit();
                editor.putString(FUENTE, valorFuente);
                editor.commit();
            }
        });
        cargarFuente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                String ultimo_fuente = preferencias.getString( FUENTE, "");

                if(ultimo_fuente=="shojumaru"){
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.shojumaruimportada);
                    caja.setTypeface(typeface);
                } else if (ultimo_fuente=="leckerli") {
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.leckerliimportada);
                    caja.setTypeface(typeface);
                } else if (ultimo_fuente=="newrocker") {
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.newrockerimportada);
                    caja.setTypeface(typeface);
                }
                // txt_text.setTypeface(null, Typeface.ITALIC);
                // txt_text.setTypeface(null, Typeface.NORMAL);
            }
        });

        salvarTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor = preferencias.edit();
                editor.putString(TEXTO, caja.getText().toString());
                editor.commit();
            }
        });
        cargarTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                String ultimo_texto = preferencias.getString( TEXTO, "");
                caja.setText(ultimo_texto);
            }
        });

        salvarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();
                editor = preferencias.edit();
                editor.putInt(COLORRED, valorRed);
                editor.putInt(COLORGREEN, valorGreen);
                editor.putInt(COLORBLUE, valorBlue);

                editor.putInt(TAMANO, valorTamano);

                editor.putString(FUENTE, valorFuente);

                editor.putString(TEXTO, caja.getText().toString());

                editor.commit();
            }
        });
        cargarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preferencias = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor editor = preferencias.edit();

                int ultimo_red = preferencias.getInt( COLORRED, 0);
                barraRed.setProgress(ultimo_red);

                int ultimo_green = preferencias.getInt( COLORGREEN, 0);
                barraGreen.setProgress(ultimo_green);

                int ultimo_blue = preferencias.getInt( COLORBLUE, 0);
                barraBlue.setProgress(ultimo_blue);

                // RECOGER LOS COLORES Y AL TEXTO
                int color =  0xFF000000 | (ultimo_red << 16) | (ultimo_green << 8) | ultimo_blue;
                //caja.setTextColor(Color.rgb(ultimo_red, ultimo_green, ultimo_blue));/
                    caja.setTextColor(color);


                int ultimo_tamano = preferencias.getInt( TAMANO, 0); Toast.makeText(getApplicationContext(),", " + ultimo_tamano , Toast.LENGTH_SHORT).show();

                barraTamano.setProgress(ultimo_tamano);
                caja.setTextSize(ultimo_tamano * 10);

                String ultimo_fuente = preferencias.getString( FUENTE, "");
                //caja.setTypeface(Typeface.SANS_SERIF, Typeface.ITALIC);




                if(ultimo_fuente=="shojumaru"){
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.shojumaruimportada);
                    caja.setTypeface(typeface);
                } else if (ultimo_fuente=="leckerli") {
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.leckerliimportada);
                    caja.setTypeface(typeface);
                } else if (ultimo_fuente=="newrocker") {
                    Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.newrockerimportada);
                    caja.setTypeface(typeface);
                }


                String ultimo_texto = preferencias.getString( TEXTO, "");
                caja.setText(ultimo_texto);
            }
        });



    }

// Cambier color cuando muevo las barras
    private void cambiarColor() {
        valorRed = barraRed.getProgress();
        valorGreen = barraGreen.getProgress();
        valorBlue = barraBlue.getProgress();
        int color =  0xFF000000 | (valorRed << 16) | (valorGreen << 8) | valorBlue;
        //caja.setTextColor(Color.rgb(ultimo_red, ultimo_green, ultimo_blue));/
        caja.setTextColor(color);

    }


// Cambia el tamaño
    private void cambiarTamano() {
        valorTamano = barraTamano.getProgress();
        caja.setTextSize(valorTamano * 10);
    }
}



// https://www.youtube.com/watch?v=sALSphjvJwM