package com.example.frutas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;


public class WebbrowserActivity extends AppCompatActivity {

    Button boton;
    WebView web_browser;
    EditText texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webbrowser);

        boton = (Button) findViewById(R.id.button_webbrowser);
        web_browser = (WebView) findViewById(R.id.webView);
        texto = (EditText) findViewById(R.id.editText_direccion);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                web_browser.loadUrl(String.valueOf(texto.getText()));

            }
        });
    }
}