package com.example.frutas;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DBAdapter { public static final String CLAVE_ID = "id";
    public static final String CLAVE_MANZANAS = "manzanas";
    public static final String CLAVE_PLATANOS = "platanos";
    public static final String CLAVE_NARANJAS = "naranjas";
    public static final String CLAVE_UVAS = "uvas";
    public static final String CLAVE_PERAS = "peras";

    private static final String TAG = "DBAdapter";

    private static final String BBDD_NOMBRE = "frutas_frutitas2";
    private static final String BBDD_TABLA = "frutas";
    private static final int BBDD_VERSION = 1;

    private static final String BBDD_CREAR =
            "CREATE TABLE frutas (id integer primary key autoincrement, "
                    + "manzanas integer not null, platanos integer not null, "
                    + "naranjas integer not null, /*year text not null*/ uvas integer not null, peras integer not null);";

    private final Context context;
    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    public DBAdapter (Context context) {
        this.context = context;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, BBDD_NOMBRE, null, BBDD_VERSION);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(BBDD_CREAR);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db,
                              int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS frutas");
            onCreate(db);

        }
    }

    //Abrir base de datos
    public DBAdapter open() throws SQLException {
        db=DBHelper.getWritableDatabase();
        return this;
    }

    //Cerrar base de datos
    public void close() {
        DBHelper.close();
    }

    //Insertar discos
    public long insertar_frutas(int manzanas, int platanos, int naranjas, /*String year*/ int uvas, int peras) {
        Toast.makeText(context.getApplicationContext(), "peras" + peras, Toast.LENGTH_SHORT).show();

        ContentValues initialValues = new ContentValues();
        initialValues.put(CLAVE_MANZANAS, manzanas);
        initialValues.put(CLAVE_PLATANOS, platanos);
        initialValues.put(CLAVE_NARANJAS, naranjas);
        initialValues.put(CLAVE_UVAS, uvas);
        initialValues.put(CLAVE_PERAS, peras);

        return db.insert(BBDD_TABLA, null, initialValues);
    }

    //Borrar discos por id
    public boolean borrar_disco(long id) {
        return db.delete(BBDD_TABLA, CLAVE_ID + "=" + id,
                null ) > 0 ;
    }



    //Consultar todos los discos
    public Cursor consultar_todos() {
        Cursor cursor = db.query(true,
                BBDD_TABLA, new String[] {CLAVE_ID, CLAVE_MANZANAS,
                        CLAVE_PLATANOS, CLAVE_NARANJAS, /*String.valueOf(CLAVE_YEAR),*/ CLAVE_UVAS, CLAVE_PERAS},
                null,null,null,
                null, null, null);

        return cursor;
    }

    //Consultar un disco por id
    public Cursor consultar_disco(int id) {
        Toast.makeText(context.getApplicationContext(),"Voy a consultar todos", Toast.LENGTH_SHORT).show();

        Cursor cursor = db.query(true,
                BBDD_TABLA, new String[] {CLAVE_ID, CLAVE_MANZANAS,
                        CLAVE_PLATANOS, CLAVE_NARANJAS, /*String.valueOf(CLAVE_YEAR),*/CLAVE_UVAS, CLAVE_PERAS},
                CLAVE_ID + "=" + id,null,null,
                null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        return cursor;
    }


    public boolean borrar_TodasFrutas() {
        return db.delete(BBDD_TABLA, null,null ) > 0 ;
    }







    /*
    //Consultar un disco por id
    public Cursor consultar_discoPorTitle(String title) {
        Cursor cursor = db.query(true,
                BBDD_TABLA, new String[] {CLAVE_ID, CLAVE_MANZANAS,
                        CLAVE_PLATANOS, CLAVE_NARANJAS, CLAVE_UVAS, CLAVE_PERAS},
                CLAVE_MANZANAS + "= '" + title + "'",null,null,
                null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        return cursor;
    }


    public boolean modificarDisco(String title , String artist, String soporte, int year, String cover, String titleAnterior) {
        Toast.makeText(context.getApplicationContext(), "entro al modificar title anterior: " + titleAnterior, Toast.LENGTH_LONG).show();



        ContentValues initialValues = new ContentValues();
        initialValues.put(CLAVE_TITLE, title);
        initialValues.put(CLAVE_ARTIST, artist);
        initialValues.put(CLAVE_TYPE, soporte);
        initialValues.put(CLAVE_YEAR, year);
        initialValues.put(CLAVE_COVER, cover);

        return db.update( BBDD_TABLA,initialValues,CLAVE_TITLE + "= '" + titleAnterior + "'",
                null ) > 0 ;




    }
*/



}





// https://academiaandroid.com/sqlite-en-app-android-actualizar-eliminar-y-consultar-datos/
// https://www.stechies.com/sqlite-